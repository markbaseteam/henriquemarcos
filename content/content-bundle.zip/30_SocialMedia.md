# 📩

E-mail 
- [Personal](mailto:henriquejbmarcos@gmail.com)
- [Maastricht](mailto:h.jbmarcos@maastrichtuniversity.nl)

Twitter [@henriquemarcos5](https://twitter.com/henriquemarcos5)

LinkedIn [henriquejbmarcos](https://www.linkedin.com/in/henriquejbmarcos)