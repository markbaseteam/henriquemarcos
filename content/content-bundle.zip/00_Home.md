 🏠

Hey! I'm Henrique, and this is my website!

![[hIMG_6428.jpg]]

If you're a student looking for teaching materials, click [[10_Teaching|here]]. 

Here is a basic table of contents for this website:
- 📚 [[10_Teaching]]
- 🔬 [[20_Research]]
- 📩 [[30_SocialMedia]]
- 🌱 [[40_Bio]]


