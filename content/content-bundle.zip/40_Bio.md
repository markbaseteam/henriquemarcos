# 🌱

Here you can find a short bio. If you want to check my publications, click [[20_Research|here]].

### 2008-2012
- Bachelor's degree in law at the University Centre of João Pessoa (Centro Universitário de João Pessoa, UNIPê).
- Got into University in 2008 at age 16; got his bachelor's diploma in 2012 at 21
### 2013-2015
- Passed the Brazilian Bar (Ordem dos Advogados do Brasil, OAB) examination and was admitted to the Brazilian Bar at age 21
- From 2013 to 2015, he focused on working as a lawyer and legal consultant in Brazilian Public Law
### 2016-2018
- Began his master's degree (M.Sc., LL.M.) in legal sciences at the Federal University of Paraíba (UFPB). 
	- His master's research focused on international and human rights law. 
		- His dissertation was on the interaction between the International Court of Justice and the Security Council in light of Hans Kelsen's work.
	- During his master’s, he worked as a teaching and research assistant in the Public Law department of UFPB’s Centre for Legal Sciences. 
	- Henrique obtained his master’s diploma in 2018. 
	- In 2018, Henrique moved to São Paulo to continue working as a lawyer. 
		- In São Paulo, his practise focused on anti-money laundering compliance for fintech companies and crypto/blockchain startups. 
### 2019
- Began his doctoral research at the University of São Paulo (USP)
	- At USP, Henrique worked as a teaching and research assistant in the department of International and Comparative Law, he was financed by USP’s Educational Improvement Programme (PAE). 
### 2020
- Henrique began his doctoral research at Maastricht University (UM). 
### 2021
- Held a temporary position as a lecturer at UM’s department of Foundations and Methods of Law.
	- Received an international internship grant from Coordenação de Aperfeiçoamento de Pessoal de Ensino Superior (CAPES). 
### 2022
- Finished writing his doctoral dissertation.
- UM’s Department of Foundations and Methods of Law hired him as a lecturer.